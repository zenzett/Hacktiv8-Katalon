>**DISCLAIMER**\
>Semua informasi di sini diterbitkan dengan tujuan baik dan murni hanya untuk informasi umum.\
>Benar atau tidaknya, kembali kepada referensi masing-masing individu.\
>Sekian, terima kasih.
>
>>**Panduan**\
>		1. Buka Katalon Studio > Klik Open Project > Pilih folder project\
>		2. Klik Test yang diinginkan > Klik tombol Run (Ctrl + Shift + A)

&nbsp;
- - - -
**Nama        : Ahmad Zain Azharul Falah**\
**Kode Peserta : KSAT006ONL004**\
**Link Github  :** [![GitHub followers](https://img.shields.io/github/followers/zenzett?label=Zain&style=social)](https://github.com/zenzett/Hacktiv8-Katalon)
- - - -

&nbsp;
## Assignment 1

&nbsp;
### Website Test Automation (CURA Website)

&nbsp;